<?php
// Database connection
$host = 'localhost';
$db = 'shift_management';
$user = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get tireCode from the form or AJAX request
    $tireCode = $_GET['tireCode'] ?? null;

    if ($tireCode) {
        // Fetch details from the tires table
        $stmt = $pdo->prepare("SELECT brand, tireWeight, pressNumber FROM tires WHERE tireCode = ?");
        $stmt->execute([$tireCode]);
        $details = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($details) {
            echo json_encode($details); // Return details as JSON
        } else {
            echo json_encode(['error' => 'No details found for the selected tire code.']);
        }
    } else {
        echo json_encode(['error' => 'Tire code is required.']);
    }
} catch (PDOException $e) {
    echo json_encode(['error' => "Database connection failed: " . $e->getMessage()]);
}
?>
